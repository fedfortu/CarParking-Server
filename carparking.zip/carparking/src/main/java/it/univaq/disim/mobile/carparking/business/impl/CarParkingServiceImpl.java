package it.univaq.disim.mobile.carparking.business.impl;

public class CarParkingServiceImpl {
}

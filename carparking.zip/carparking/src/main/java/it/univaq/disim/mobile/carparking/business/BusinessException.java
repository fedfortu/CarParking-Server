package it.univaq.disim.mobile.carparking.business;

public class BusinessException {
}

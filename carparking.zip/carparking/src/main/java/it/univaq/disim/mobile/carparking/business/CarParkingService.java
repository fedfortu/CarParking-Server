package it.univaq.disim.mobile.carparking.business;

public interface CarParkingService {
}
